from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
from math import *





def draw_points(x, y):
    glPointSize(2) #pixel size. by default 1 thake
    glBegin(GL_POINTS)
    glVertex2f(x,y) #jekhane show korbe pixel
    glEnd()

def nodirpar():
    draw_lines(130, 250, 250, 200)
    draw_lines(250, 200, 100, 150)
    draw_lines(100, 150, 325, 80)
    draw_lines(325, 80, 200, 60)
    draw_lines(200, 60, 120, 40)
    draw_lines(120, 40, 190, 20)
    draw_lines(190, 20, 250, 0)




def draw_lines(x1, y1,x2,y2):
    glPointSize(5) #pixel size. by default 1 thake
    glBegin(GL_LINES)
    glVertex2f(x1,y1)
    glVertex2f(x2,y2)
    glEnd()

def draw_triangle(x1,y1,x2,y2,x3,y3):
    glPointSize(5) #pixel size. by default 1 thake
    glBegin(GL_TRIANGLES)
    glVertex2f(x1,y1)
    glVertex2f(x2,y2)
    glVertex2f(x3,y3)#jekhane show korbe pixel
    glEnd()
def circle_point(x,y,x0,y0):
 draw_points(x+x0,y+y0)
 draw_points(y+y0,x+x0)
 draw_points(y+y0,-x+x0)
 draw_points(x+x0,-y+y0)
 draw_points(-x+x0,-y+y0)
 draw_points(-y+y0,-x+x0)
 draw_points(-y+y0, x+x0)
 draw_points(-x+x0, y+y0)


def midpointcircle(r,x0,y0):
 d=1-r
 x=0
 y=r
 circle_point(x,y,x0,y0)
 while x<y:
  if d<0:
    d=d+ 2*x +3
    x=x+1
  else:
   d=d+ 2*x - 2*y +5
   x=x+1
   y=y-1
  circle_point(x,y,x0,y0)

def window(x,y):
    draw_lines(x, y, x-20,y )
    draw_lines(x-20, y, x-20, y-32)
    draw_lines(x-20, y-32, x, y-32)
    draw_lines(x, y-32, x, y)

def draw_house():
    #basharshape
    draw_lines(10,10,10,100)
    draw_lines(10,100,100,100)
    draw_lines(100,100,100,10)
    draw_lines(100,10,10,10)
    #basharchal
    draw_triangle(10,100,100,100,55,145)
    #Door
    draw_lines(45, 10, 45 , 65)
    draw_lines(45, 65, 65, 65)
    draw_lines(65, 65, 65, 10)
    #draw_lines(100, 10, 10, 10)
    #dorjarlocker
    draw_points(60,37)
    #basharwindow
    window(40,65)
    window(90,65)

def pahar():
    draw_lines(0, 250, 500, 250)
    draw_lines(0, 250, 125, 375)
    draw_lines(125, 375, 250, 250)
    draw_lines(250, 250, 375, 375)
    draw_lines(375, 375, 500, 250)


def iterate():
    glViewport(0, 0, 500, 500)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(0.0, 500, 0.0, 500, 0.0, 1.0)
    glMatrixMode (GL_MODELVIEW)
    glLoadIdentity()

def showScreen():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    iterate()
    glColor3f(0.0, 1.0, 0.0) #konokichur color set (RGB)
    #call the draw methods here
    #draw_points(250, 250)
    draw_house()
    pahar()
    midpointcircle(30,400,400)
    nodirpar()
    draw_lines(300,200,400,200)
    draw_lines(270,220,300,200)
    draw_lines(270,220,430,220)
    draw_lines(430,220,400,200)
    glutSwapBuffers()



glutInit()
glutInitDisplayMode(GLUT_RGBA)
glutInitWindowSize(500, 500) #window size
glutInitWindowPosition(0, 0)
wind = glutCreateWindow(b"Final Scenery 423") #window name
glutDisplayFunc(showScreen)

glutMainLoop()
